package com.cniao5.cniao5play.presenter;

/**
 * Created by Ivan on 2017/1/3.
 */

public interface BasePresenter {
}
