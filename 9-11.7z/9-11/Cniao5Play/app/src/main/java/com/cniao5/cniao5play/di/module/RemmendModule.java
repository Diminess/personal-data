package com.cniao5.cniao5play.di.module;

import android.app.ProgressDialog;
import android.support.v4.app.Fragment;

import com.cniao5.cniao5play.data.RecommendModel;
import com.cniao5.cniao5play.data.http.ApiService;
import com.cniao5.cniao5play.presenter.RecommendPresenter;
import com.cniao5.cniao5play.presenter.contract.RecommendContract;
import com.cniao5.cniao5play.ui.adapter.RecomendAppAdatper;
import com.cniao5.cniao5play.ui.fragment.RecommendFragment;

import dagger.Module;
import dagger.Provides;

/**
 * 菜鸟窝http://www.cniao5.com 一个高端的互联网技能学习平台
 *
 * @author Ivan
 * @version V1.0
 * @Package com.cniao5.cniao5play.di
 * @Description: ${TODO}(用一句话描述该文件做什么)
 * @date
 */




@Module
public class RemmendModule {



    private RecommendContract.View mView;

    public RemmendModule(RecommendContract.View view){


        this.mView = view;
    }





    @Provides
    public RecommendContract.View provideView(){

        return mView;
    }



    @Provides
    public RecommendModel privodeModel(ApiService apiService){

        return  new  RecommendModel(apiService);
    }



    @Provides
    public ProgressDialog provideProgressDialog(RecommendContract.View view){

        return new ProgressDialog(((RecommendFragment)view).getActivity());
    }




}
